/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyecto_progra2.model1;

/**
 *
 * @author Usuario
 */
public class WeeklyMeal {
    private Dish dish;
    private String weekday;
    
    public WeeklyMeal() {
    }

    public WeeklyMeal(Dish dish, String weekday) {
        this.dish = dish;
        this.weekday = weekday;
    }

    public void setDish(Dish dish) {
        this.dish = dish;
    }

    public void setWeekday(String weekday) {
        this.weekday = weekday;
    }

    public Dish getDish() {
        return dish;
    }

    public String getWeekday() {
        return weekday;
    }

    @Override
    public String toString() {
        return "WeeklyMeal{" + "dish=" + dish + ", weekday=" + weekday + '}';
    }
}
