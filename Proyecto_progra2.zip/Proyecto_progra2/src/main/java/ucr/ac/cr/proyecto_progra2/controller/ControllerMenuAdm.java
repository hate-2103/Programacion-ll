/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyecto_progra2.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import ucr.ac.cr.proyecto_progra2.model1.DishArray;
import ucr.ac.cr.proyecto_progra2.model1.User;
import ucr.ac.cr.proyecto_progra2.model1.UserArray;
import ucr.ac.cr.proyecto_progra2.model1.WeeklyMealsRegistered;
import ucr.ac.cr.proyecto_progra2.view.GUIChangedPassword;
import ucr.ac.cr.proyecto_progra2.view.GUIMain;
import ucr.ac.cr.proyecto_progra2.view.GUIRegisteredAdministrator;
import ucr.ac.cr.proyecto_progra2.view.GUIWeaklyMeals;

/**
 *
 * @author Usuario
 */
public class ControllerMenuAdm implements ActionListener{
    private GUIMain guiMenuAdm;
    private GUIRegisteredAdministrator guiAdministrator;
    private GUIChangedPassword guiChangePassword;
    private UserArray usersArray;
    private User user;
    private DishArray dishArray;
    private WeeklyMealsRegistered mealsRegistered;

    public ControllerMenuAdm(UserArray usersArray, String rolUser) {
        this.usersArray = usersArray;
        this.mealsRegistered= new WeeklyMealsRegistered();
        this.dishArray= new DishArray();
        this.guiMenuAdm = new GUIMain();
        this.guiMenuAdm.listenJmi(this);
        this.guiMenuAdm.setVisible(true);
        verifyRolUser(rolUser);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Ordenes":
                System.out.println("Abre ventana de ordenes");
                break;

            case "Menu":
                new ControllerWeeklyMeals(mealsRegistered);
                break;

            case "Registrar":
                new DishController(dishArray);
                break;

            case "Compra":
                System.out.println("Abre ventana de compras");
                break;

            case "Administrador":

                this.guiAdministrator = new GUIRegisteredAdministrator();
                this.guiAdministrator.listenButtons(this);
                this.guiAdministrator.setVisible(true);
                break;

            case "nuevoAdministrador":
                String userName = this.guiAdministrator.getUserName();
                String password = this.guiAdministrator.getPassword();
                String passwordVerification = this.guiAdministrator.getPasswordVerification();
                if (password.equals(passwordVerification)) {
                    User user = new User(userName, password, "administrator");
                    GUIRegisteredAdministrator.sendMessage(this.usersArray.addUser(user));
                    this.guiAdministrator.cleanTxt();
                } else {
                    GUIRegisteredAdministrator.sendMessage("La contraseña no coincide, ingresela de nuevo");
                    this.guiAdministrator.cleanPasswords();
                }

                break;

            case "cambiarClave":

                this.guiChangePassword = new GUIChangedPassword();
                this.guiChangePassword.listenButton(this);
                this.guiChangePassword.setVisible(true);
                break;
                
            case "Cambiar":
                String userNameChange = this.guiChangePassword.getUserName();
                this.user = this.usersArray.searchUser(userNameChange);
                String rolUser = this.user.getRol();
                String userPassword = this.guiChangePassword.getPasswordVerification();
                if (this.usersArray.verifyPassword(user, userPassword)) {
                    String newPassworString = this.guiChangePassword.getNewPassword();
                    User userEdit = new User(userNameChange, newPassworString, rolUser);
                    GUIRegisteredAdministrator.sendMessage(this.usersArray.editUser(userEdit));
                    this.guiChangePassword.clean();
                } else {
                    GUIRegisteredAdministrator.sendMessage("la contraseña no coincide con este usuario");
                }

                break;
            case "Exit":
                this.guiMenuAdm.dispose();
                break;
            default:
                throw new AssertionError();
        }
    }

    public void verifyRolUser(String rolUser) {
        if (rolUser.equalsIgnoreCase("student")) {
            this.guiMenuAdm.setEnabledCustomers(false);
        }
    }
}
