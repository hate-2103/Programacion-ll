/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyecto_progra2.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import ucr.ac.cr.proyecto_progra2.model1.User;
import ucr.ac.cr.proyecto_progra2.model1.UserArray;
import ucr.ac.cr.proyecto_progra2.view.GUIRegisteredUser;

/**
 *
 * @author Usuario
 */
public class ControllerRegisteredUser implements ActionListener{
    private GUIRegisteredUser guiRegistredUser;
    private UserArray usersRegistred;
    
    
    public ControllerRegisteredUser(UserArray usersRegistred) {
        this.usersRegistred = usersRegistred;
        this.guiRegistredUser = new GUIRegisteredUser();
        this.guiRegistredUser.listenButtons(this);
        this.guiRegistredUser.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Registrarse":
                String userName = this.guiRegistredUser.getUserName();
                String password = this.guiRegistredUser.getPassword();
                String passwordVerification = this.guiRegistredUser.getPasswordVerification();
                
                if (password.equals(passwordVerification)) {
                    User user = new User(userName, password, "student");
                    GUIRegisteredUser.sendMessage(this.usersRegistred.addUser(user));
                    this.guiRegistredUser.cleanTxt();
                } else {
                    GUIRegisteredUser.sendMessage("La contraseña no coincide, ingresela de nuevo");
                    this.guiRegistredUser.cleanPasswords();
                } 
                break;
            case "Salir":
                this.guiRegistredUser.dispose();
                break;
            default:
                throw new AssertionError();
        }
    }
}
