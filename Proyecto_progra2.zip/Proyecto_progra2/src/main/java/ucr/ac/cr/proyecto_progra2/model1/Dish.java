/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyecto_progra2.model1;

import javax.swing.JOptionPane;

/**
 *
 * @author Usuario
 */
public class Dish {
     private String component1;
    private String component2;
    private String component3;
    private String component4;
    private String component5;
    private String name;
    private String type;
    private double price;
    
    public static final String[] FOOD_DATA= {"Componente 1","Componente 2","Componente 3","Componente 4","Componente 5","Nombre","Tipo","Precio"};

    public Dish() {
    }

    public Dish(String component1, String component2, String component3, String component4, String component5, String name, String type, double price) {
        this.component1 = component1;
        this.component2 = component2;
        this.component3 = component3;
        this.component4 = component4;
        this.component5 = component5;
        this.name = name;
        this.type = type;
        this.price=price;
    }
    
    public String getData(int colum){
        switch(colum){
           case 0: return this.getComponent1();
           case 1: return this.getComponent2();
           case 2: return this.getComponent3();
           case 3: return this.getComponent4();
           case 4: return this.getComponent5();
           case 5: return this.getName();
           case 6: return this.getType();
           case 7: return String.valueOf(this.getPrice());
       }
       return "";
    }

    public String getComponent1() {
        return component1;
    }

    public void setComponent1(String component1) {
        this.component1 = component1;
    }

    public String getComponent2() {
        return component2;
    }

    public void setComponent2(String component2) {
        this.component2 = component2;
    }

    public String getComponent3() {
        return component3;
    }

    public void setComponent3(String component3) {
        this.component3 = component3;
    }

    public String getComponent4() {
        return component4;
    }

    public void setComponent4(String component4) {
        this.component4 = component4;
    }

    public String getComponent5() {
        return component5;
    }

    public void setComponent5(String component5) {
        this.component5 = component5;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Dish{" + "component1=" + component1 + ", component2=" + component2 + ", component3=" + component3 + ", component4=" + component4 + ", component5=" + component5 + ", name=" + name + ", type=" + type + ", price=" + price + '}';
    }
    
    public static void sendMessage(String message){
        JOptionPane.showMessageDialog(null, message);
    }
}
