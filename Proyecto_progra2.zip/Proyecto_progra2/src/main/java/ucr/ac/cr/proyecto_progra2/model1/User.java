/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyecto_progra2.model1;

/**
 *
 * @author Usuario
 */
public class User {
    private String userName;
    private String password;
    private String rol;

    public User(String userName, String password, String rol) {
        this.userName = userName;
        this.password = password;
        this.rol = rol;
    }
    
   public static String[] TITLE_USER = {"userName", "password", "rol"};

    User() {
       
    }

    public String getDataRow(int colum){
        switch (colum) {
            case 0: return this.getUserName();
            case 1: return this.getPassword();
            case 2: return this.getRol();
          
        }
        return "";
    }
    
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    @Override
    public String toString() {
        return "User{" + "userName=" + userName + ", password=" + password + ", rol=" + rol + '}';
    }
}
