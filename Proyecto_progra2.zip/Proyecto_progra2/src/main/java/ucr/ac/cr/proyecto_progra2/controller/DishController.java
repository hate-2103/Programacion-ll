/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyecto_progra2.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import ucr.ac.cr.proyecto_progra2.model1.Dish;
import ucr.ac.cr.proyecto_progra2.model1.DishArray;
import ucr.ac.cr.proyecto_progra2.view.ButtonsPanel;
import ucr.ac.cr.proyecto_progra2.view.GUIMenu;

/**
 *
 * @author Usuario
 */
public class DishController implements ActionListener{
    private GUIMenu guiMenu;
    private Dish dish;
    private Dish dishEdit;
    private DishArray dishArray;
    private ButtonsPanel buttons;

    public DishController(DishArray array) {
        this.guiMenu = new GUIMenu();
        this.buttons=this.guiMenu.getButtonsPanel();
        this.buttons.listenButtons(this);
        this.dishArray=array;
        this.guiMenu.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Agregar":
                this.dish = this.guiMenu.getDish();
                JOptionPane.showMessageDialog(null, this.dishArray.add(dish));
                this.guiMenu.clean();
                break;
                
            case "Buscar":
                String name = this.guiMenu.getDishName();
                this.dish = this.dishArray.getFood(name);
                this.guiMenu.setDish(dish);
                break;
                
            case "Eliminar":
                this.dish = this.guiMenu.getDish();
                JOptionPane.showMessageDialog(null, this.dishArray.delete(dish));
                this.guiMenu.clean();
                break;
                
            case "Editar":
                this.dishEdit= this.guiMenu.getDish();
                JOptionPane.showMessageDialog(null, this.dishArray.edit(dishEdit));
                this.guiMenu.clean();
                break;
                
            case "Salir":
                this.guiMenu.dispose();
                break;
        }
    }
}
