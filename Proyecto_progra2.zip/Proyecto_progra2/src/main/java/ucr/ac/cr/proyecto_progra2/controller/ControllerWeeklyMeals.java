/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyecto_progra2.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import jdk.javadoc.doclet.Reporter;
import ucr.ac.cr.proyecto_progra2.model1.Dish;
import ucr.ac.cr.proyecto_progra2.model1.DishArray;
import ucr.ac.cr.proyecto_progra2.model1.WeeklyMeal;
import ucr.ac.cr.proyecto_progra2.model1.WeeklyMealsRegistered;
import ucr.ac.cr.proyecto_progra2.view.GUIWeaklyMeals;
import ucr.ac.cr.proyecto_progra2.view.Report;

/**
 *
 * @author Usuario
 */
public class ControllerWeeklyMeals implements ActionListener, MouseListener {

    private GUIWeaklyMeals guiWeeklyMeals;
    private WeeklyMeal weeklyMeal;
    private Dish dish;
    private DishArray dishArray;
    private WeeklyMealsRegistered mealsRegistered;
    private Report report;

    public ControllerWeeklyMeals(WeeklyMealsRegistered mealsRegistered) {
        this.guiWeeklyMeals = new GUIWeaklyMeals();
        guiWeeklyMeals.setCbWeek();
        this.guiWeeklyMeals.listenButtons(this);
        dishArray = new DishArray();
        weeklyMeal = new WeeklyMeal();
        mealsRegistered = new WeeklyMealsRegistered();
        report = new Report();
        this.report.listenMouse(this);
        this.guiWeeklyMeals.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.err.println(e.getActionCommand());
        switch (e.getActionCommand()) {

            case "Registrar":
                if (guiWeeklyMeals.blankSpaces() == false) {
                    dish = dishArray.getFood(guiWeeklyMeals.getData(0));//traigo el platillo con el nombre del txtNombre en guiWeeklyMeals
                    System.err.println(dish);
                    weeklyMeal = new WeeklyMeal(dish, this.guiWeeklyMeals.getData(6));//guardo el dish y el weekday que aparece en el cbWeek del guiWeeklyMeals
                    dish.sendMessage(this.mealsRegistered.add(weeklyMeal));//agrego el objeto weeklyMeals al array correspondiente
                    guiWeeklyMeals.cleanData();//limpio la informacion
                } else {
                    dish.sendMessage("Error, Rellene todos los espacios en blanco");
                }

                break;
            case "Buscar_Platillo":
                System.err.println("entra a buscar");
                report.setDataTable(dishArray.getMatrixDish(), dish.FOOD_DATA);
                report.setVisible(true);
                break;
            case "Vaciar":
                dish.sendMessage(mealsRegistered.clearOut());
                break;
            case "Eliminar":
                dish.sendMessage(mealsRegistered.delete(guiWeeklyMeals.getData(0)));
                break;
            case "Salir":
                guiWeeklyMeals.dispose();
                break;
            default:
                throw new AssertionError();
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        guiWeeklyMeals.setData(new Dish(report.getDataRow()[0],
                report.getDataRow()[1], report.getDataRow()[2], report.getDataRow()[3],
                report.getDataRow()[4], report.getDataRow()[5], report.getDataRow()[6],
                Double.parseDouble(report.getDataRow()[7])));
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
