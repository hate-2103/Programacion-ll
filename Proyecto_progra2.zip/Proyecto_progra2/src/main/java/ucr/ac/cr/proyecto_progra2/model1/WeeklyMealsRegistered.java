/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyecto_progra2.model1;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author Usuario
 */
public class WeeklyMealsRegistered {
     private ArrayList<WeeklyMeal> weeklyMealsList;
    private WeeklyMeal meal;
    private String fileName="weeklyMeals.json";
    private File file;
            
    public WeeklyMealsRegistered() {
        file=new File(fileName);
        try {
            file.createNewFile();
        } catch (IOException ex) {
            Logger.getLogger(DishArray.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.weeklyMealsList = readJSON();
    }
    
    public String add(WeeklyMeal meal){
        System.err.println(meal);
        if(weeklyMealsList.size()==0){
            weeklyMealsList.add(meal);
            System.err.println("size(): "+weeklyMealsList.size());
            writeJSON();
            return "Platillo semanal registrado correctamente";
        }else{
            for (WeeklyMeal weeklyMeal : weeklyMealsList) {
                if(!weeklyMeal.getDish().getName().equals(meal.getDish().getName())){
                    weeklyMealsList.add(meal);
                    writeJSON();
                    return "Platillo semanal registrado correctamente";
                }else{
                    return "El Platillo semanal ya esta registrado";
                }
            }//fin for
        }
        System.err.println("Error al agregar Platillo semanal");
        return "Error al agregar Platillo semanal";
    }
    
    public int search(String name){ 
        for (int i = 0; i < weeklyMealsList.size(); i++) {
            if (this.weeklyMealsList.get(i).getDish().getName().equalsIgnoreCase(name)) {
                return i;
            }
        }
        return -1;
    }
    
    public String clearOut(){
        weeklyMealsList.clear();
        writeJSON();
        return "Todos Platillos semanales registrados han sido correctamente eliminados";
    }
    
    public WeeklyMeal getWeeklyMeal(String name){
        this.weeklyMealsList = readJSON(); 
        for (WeeklyMeal meal : weeklyMealsList) {
            if(meal.getDish().getName().equals(name)){
                return meal;
            }
        }
        return null;
    }
    
    public String delete(String name){
        for (WeeklyMeal meal : weeklyMealsList) {
            if(meal.getDish().getName().equals(name)){
                weeklyMealsList.remove(meal);
                writeJSON();
                return "Platillo semanal eliminado correctamente";
            }else{
                return "El platillo semanal aun no esta registrado";
            }
        }
        return "Error al eliminar el platillo semanal";
    }
    
    public void writeJSON() {
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject = new JSONObject();
        
        for (int i = 0; i < weeklyMealsList.size(); i++) {
            System.err.println("entra en el for: "+i);
            Dish dish = weeklyMealsList.get(i).getDish();
            
            // Convert Dish object to JSON
            JSONObject dishJson = new JSONObject();
            dishJson.put("component1", dish.getComponent1());
            dishJson.put("component2", dish.getComponent2());
            dishJson.put("component3", dish.getComponent3());
            dishJson.put("component4", dish.getComponent4());
            dishJson.put("component5", dish.getComponent5());
            dishJson.put("name", dish.getName());
            dishJson.put("type", dish.getType());
            dishJson.put("price", dish.getPrice());

            jsonObject.put("dish", dishJson);
            jsonObject.put("weekday", weeklyMealsList.get(i).getWeekday());

            jsonArray.add(jsonObject);
        }
        try (FileWriter writer = new FileWriter(fileName)) {
            writer.write(jsonArray.toJSONString());
            writer.flush();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public ArrayList<WeeklyMeal> readJSON() {//para leer el archivo JSON
        ArrayList<WeeklyMeal> mealList = new ArrayList<>();
        JSONParser jsonParser = new JSONParser();
        try (FileReader reader = new FileReader(fileName)) {
            if(file.length()==0){
                return mealList;
            }
            Object object = jsonParser.parse(reader);
            JSONArray jsonArray = (JSONArray) object;
        for (Object object1 : jsonArray) {
            JSONObject jsonObject = (JSONObject) object1;
            JSONObject dishJson = (JSONObject) jsonObject.get("dish");
            String name = (String) dishJson.get("name");
            String type = (String) dishJson.get("type");
            double price = (double) dishJson.get("price");
            // Assuming components are stored as individual strings
            String component1 = (String) dishJson.get("component1");
            String component2 = (String) dishJson.get("component2");
            String component3 = (String) dishJson.get("component3");
            String component4 = (String) dishJson.get("component4");
            String component5 = (String) dishJson.get("component5");
            // Create a Dish object with the parsed values
            Dish dish = new Dish( component1, component2, component3, component4, component5, name, type, price);
            String weekday = (String) jsonObject.get("weekday");
            WeeklyMeal meal = new WeeklyMeal(dish, weekday);
            mealList.add(meal);
        }
        } catch (IOException | ParseException ex) {
            ex.printStackTrace();
        }
        return mealList;
    }
}
