/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyecto_progra2.model1;

import java.io.FileWriter;
import java.util.ArrayList;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author Usuario
 */
public class UserArray {
     private ArrayList<User> listUsers;

    public UserArray() {
        getArrayUsersJson();
    }

    public void getArrayUsersJson() {
        listUsers = new ArrayList<>();
        JSONFile jsonFile = new JSONFile("usuarios.json");
        JSONArray jsonArray = jsonFile.readJson();

        for (Object object : jsonArray) {
            JSONObject obj = (JSONObject) object;
            User user = new User();
            user.setUserName(String.valueOf(obj.get("userName")));
            user.setPassword(String.valueOf(obj.get("password")));
            user.setRol(String.valueOf(obj.get("rol")));

            this.listUsers.add(user);
        }
    }

//     method to check if a user already exists in the list
    public boolean verifyUser(String userName) {
        for (User listUser : listUsers) {
            if (listUser.getUserName().equals(userName)) {
                return true;
            }
        }
        return false;
    }

//    Method to add a user to the list, checking that the username is not repeated
    public String addUser(User newUser) {
        if (!verifyUser(newUser.getUserName())){
            if (newUser != null) {
            JSONFile jsonFile = new JSONFile("usuarios.json");
            JSONObject obj = new JSONObject();
            obj.put("userName", newUser.getUserName());
            obj.put("password", newUser.getPassword());
            obj.put("rol", newUser.getRol());
            jsonFile.writerJson(obj);
        }
        this.listUsers.add(newUser);
        return "¡Te has registrado exitosamente!";
        } else {
            return "Nombre de usuario ya registrado";
        }
    }
 //   method to edit an user
    public String editUser(User userEdit){
        for (int i = 0; i < this.listUsers.size(); i++) {
            if(this.listUsers.get(i).getUserName().equals(userEdit.getUserName())){
//                this.listUsers.set(i, userEdit);
                deleteUser(this.listUsers.get(i).getUserName()); //elimino de la lista
                addUser(userEdit); //añado nuevamente a la lista y escribo en el json
       
                return"Usuario modificado exitosamente";
            }
        }
        return "Usuario no modificado";
    }
    
    public String deleteUser(String userNameDelete){
        if(searchUser(userNameDelete)!=null){
            this.listUsers.remove(searchUser(userNameDelete));
            escribir();
            return "usuario eliminado";
        }
        return "Usuario no encontrado";
    }



//    Method to compare a user's password by receiving the password to verify
    public boolean verifyPassword(User user, String password) {
        return user.getPassword().equals(password);
    }

//    Method to search for a user in the list by their username and return the user
    public User searchUser(String userName) {
        for (User user : listUsers) {
            if (user.getUserName().equals(userName)) {
                return user;
            }
        }
        return null;
    }

       public void escribir(){
        JSONArray jsonArray = new JSONArray(); //nuevo arreglo de objetos json
        for (int i = 0; i < listUsers.size(); i++) {
            System.out.println(i);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("userName", listUsers.get(i).getUserName());
            jsonObject.put("password", listUsers.get(i).getPassword());
            jsonObject.put("rol", listUsers.get(i).getRol());
            
            jsonArray.add(jsonObject);     
        }
        
        try(FileWriter fileWriter = new FileWriter("usuarios.json")){
            fileWriter.write(jsonArray.toString());
            fileWriter.flush();
            fileWriter.close();
        } catch (Exception e) {
            System.out.println("Error writer"); 
       }
    }
}
