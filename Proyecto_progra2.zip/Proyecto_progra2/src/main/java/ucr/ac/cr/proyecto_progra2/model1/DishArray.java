/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyecto_progra2.model1;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author Usuario
 */
public class DishArray {
     private String fileName = "foods.json";//rchivo donde se van a guardar las comidas
    private final ArrayList<Dish> listDishes;
    private Dish dish;
    private File file;
    
    public DishArray() {
        file=new File(fileName);
        try {
            file.createNewFile();
        } catch (IOException ex) {
            Logger.getLogger(DishArray.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.listDishes = readJSON();   
    }

    public int search(String name) {//busca y devuelve la posicion en donde se encuentre el objeto
        for (int i = 0; i < listDishes.size(); i++) {
            if (this.listDishes.get(i).getName().equalsIgnoreCase(name)) {
                return i;
            }
        }
        return -1;
    }

    public Dish getFood(String name) {//busca y devuelve el objeto
        for (int i = 0; i < listDishes.size(); i++) {
            if (this.listDishes.get(i).getName().equalsIgnoreCase(name)) {
                return listDishes.get(i);
            }
        }
        return null;
    }

    public String add(Dish food) {//agrega los objetos al archivo JSON
        if (food != null) {
            if (this.search(food.getName()) == -1) {
                this.listDishes.add(food);
                writeJSON();
                return "Platillo agregado";
            } else {
                return "Platillo existente";
            }
        } else {
            return "Error al agregar";
        }
    }

    public String delete(Dish food) {//elimina los objetos del archivo
        if (this.search(food.getName()) != -1) {
            this.listDishes.remove(search(food.getName()));
            writeJSON();
            return "Platillo eliminado";
        }
        return "Error al eliminar";
    }
    
    public String edit(Dish food){
        if(this.search(food.getName())!=-1){
            this.delete(food);
            this.add(food);
            writeJSON();
            return "Platillo editado";
        }
        return "Error al editar";
    }
    
    public String[][] getMatrixDish(){
        String[][] matrixDish=new String[this.listDishes.size()][dish.FOOD_DATA.length];
        for(int i=0; i< matrixDish.length; i++){
            for (int j = 0; j < matrixDish[0].length; j++) {
                matrixDish[i][j]=this.listDishes.get(i).getData(j);
            }
        }
        return matrixDish;
    }

    public void writeJSON() {//para escribir y actualizar el archivo JSON
        JSONArray jsonArray = new JSONArray();
        for (int i = 0; i < listDishes.size(); i++) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("componente 1", listDishes.get(i).getComponent1());
            jsonObject.put("componente 2", listDishes.get(i).getComponent2());
            jsonObject.put("componente 3", listDishes.get(i).getComponent3());
            jsonObject.put("componente 4", listDishes.get(i).getComponent4());
            jsonObject.put("componente 5", listDishes.get(i).getComponent5());
            jsonObject.put("nombre", listDishes.get(i).getName());
            jsonObject.put("tipo", listDishes.get(i).getType());
            jsonObject.put("precio", listDishes.get(i).getPrice());

            jsonArray.add(jsonObject);

            try (FileWriter writer = new FileWriter(fileName)) {
                writer.write(jsonArray.toJSONString());
                writer.flush();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    public ArrayList<Dish> readJSON() {//para leer el archivo JSON
        ArrayList<Dish> list = new ArrayList<>();
        JSONParser jsonParser = new JSONParser();
        try (FileReader reader = new FileReader(fileName)) {
            if(file.length()==0){
                return list;
            }
            Object object = jsonParser.parse(reader);
            JSONArray jsonArray = (JSONArray) object;
            for (Object object1 : jsonArray) {
                JSONObject jsonObject = (JSONObject) object1;
                String comp1 = (String) jsonObject.get("componente 1");
                String comp2 = (String) jsonObject.get("componente 2");
                String comp3 = (String) jsonObject.get("componente 3");
                String comp4 = (String) jsonObject.get("componente 4");
                String comp5 = (String) jsonObject.get("componente 5");
                String name = (String) jsonObject.get("nombre");
                String type = (String) jsonObject.get("tipo");
                double price = ((double) jsonObject.get("precio"));
                Dish dish = new Dish(comp1, comp2, comp3, comp4, comp5, name, type, price);
                list.add(dish);
            }

        } catch (IOException | ParseException ex) {
            ex.printStackTrace();
        }
        return list;
    }
}
