/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyecto_progra2.model1;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author Usuario
 */
public class JSONFile {
     private String fileName;
    private JSONObject jsonObject;
    private JSONArray jsonArray;
    private JSONParser parser;

    public JSONFile(String fileName) {
        this.fileName = fileName;
        this.jsonObject = new JSONObject();
        this.jsonArray = new JSONArray();
    }
    
    //READ 
    public JSONArray readJson(){
        this.parser = new JSONParser(); 
        try (FileReader reader = new FileReader(fileName)){
            Object obj = this.parser.parse(reader);
            this.jsonArray = (JSONArray) obj;
        } catch (IOException | ParseException e) {
            System.out.println("No existing file or new file wille create");
        }
        return this.jsonArray;
    }

    public void writerJson(JSONObject jsonObject){
        this.jsonArray = this.readJson();
        this.jsonArray.add(jsonObject); 
        
        try(FileWriter fileWriter = new FileWriter(fileName)){
            fileWriter.write(this.readJson().toJSONString());
            fileWriter.flush();
            fileWriter.close();
        } catch (Exception e) {
            System.out.println("Error writer"); 
       }
    }
}
