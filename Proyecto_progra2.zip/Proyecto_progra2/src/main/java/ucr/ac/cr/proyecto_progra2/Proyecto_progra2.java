/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ucr.ac.cr.proyecto_progra2;

import ucr.ac.cr.proyecto_progra2.controller.ControllerLogin;
import ucr.ac.cr.proyecto_progra2.controller.ControllerMenuAdm;
import ucr.ac.cr.proyecto_progra2.model1.User;
import ucr.ac.cr.proyecto_progra2.model1.UserArray;

/**
 *
 * @author Usuario
 */
public class Proyecto_progra2 {

    public static void main(String[] args) {
        UserArray userArray = new UserArray();
        userArray.addUser(new User("anita", "puerto", "administrator"));
        new ControllerLogin(userArray);
    }
}
