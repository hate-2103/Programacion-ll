/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.proyecto_progra2.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import ucr.ac.cr.proyecto_progra2.model1.User;
import ucr.ac.cr.proyecto_progra2.model1.UserArray;
import ucr.ac.cr.proyecto_progra2.view.GUILogin;
import ucr.ac.cr.proyecto_progra2.view.GUIMain;
import ucr.ac.cr.proyecto_progra2.view.GUIRegisteredUser;

/**
 *
 * @author Usuario
 */
public class ControllerLogin implements ActionListener{
    private GUILogin guiLogin;
    private GUIMain guiMain;
    private User user;
    private UserArray usersRegistred;

    public ControllerLogin(UserArray usersRegistred) {
        this.usersRegistred = usersRegistred;
        this.guiLogin = new GUILogin();
        this.guiLogin.listenButtons(this);
        this.guiLogin.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Registrarse":
                new ControllerRegisteredUser(this.usersRegistred);
                break;
            case "Ingresar":
                String userName = this.guiLogin.getUserName();
                String password = this.guiLogin.getPassword();

                if (this.usersRegistred.verifyUser(userName)) {
                    GUIRegisteredUser.sendMessage("Verificando que existe este usuario");
                    this.user = this.usersRegistred.searchUser(userName);
                    if (this.usersRegistred.verifyPassword(user, password)) {
                        String rolUser = this.user.getRol();
                        new ControllerMenuAdm(this.usersRegistred, rolUser);

                    } else {
                        GUIRegisteredUser.sendMessage("La contraseña ingresa es incorrecta. Intente de nuevo");
                        this.guiLogin.cleanPassword();
                    }
                } else {
                    GUIRegisteredUser.sendMessage("Usuario no encontrado. Verifique que el nombre de usuario sea el correcto");
                }
                break;
            case "Salir":
                System.exit(0);
                break;
        }
    }
}
